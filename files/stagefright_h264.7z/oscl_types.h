
#ifndef OSCL_TYPES_H_INCLUDED
#define OSCL_TYPES_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef unsigned int uint;

#define uint8 unsigned char
#define int8 char
#define uint16 unsigned short
#define int16 short
#define uint32 unsigned int
#define int32 int

#define oscl_memset memset
#define oscl_memcpy memcpy

#ifndef OSCL_EXPORT_REF
#define OSCL_EXPORT_REF
#endif

#ifndef OSCL_IMPORT_REF
#define OSCL_IMPORT_REF
#endif

//! The NULL_TERM_CHAR is used to terminate c-style strings.
//static const char NULL_TERM_CHAR = '\0';
#ifndef NULL_TERM_CHAR
#define NULL_TERM_CHAR '\0'
#endif

#define OSCL_UNUSED_ARG(vbl) (void)(vbl)
#define OSCL_UNUSED_RETURN(value) return value

#endif  // OSCL_TYPES_H_INCLUDED
