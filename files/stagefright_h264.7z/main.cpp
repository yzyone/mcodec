
#include "oscl_types.h"
#include "avcdec_api.h"

int CBAVC_Malloc_OMX(void* aUserData, int32 aSize, int aAttribute)
{
    void* pPtr;
    pPtr = malloc(aSize);
    return (int32) pPtr;
}

void CBAVC_Free_OMX(void* aUserData, int aMem)
{
    free((uint8*) aMem);
}

int main()
{	
	FILE* fp;
	int  aInBufSize=419737;
	unsigned char *aInputBuf=(unsigned char*)malloc(1024*1024); // �����ļ����ڴ�й¶����ʱ����

	unsigned char* pNalBuffer;
	int NalSize, NalType, NalRefId;

	AVCDec_Status   Status;
	AVCHandle       AvcHandle;

	oscl_memset(&AvcHandle, 0, sizeof(AvcHandle));
	AvcHandle.CBAVC_Malloc = CBAVC_Malloc_OMX;
    AvcHandle.CBAVC_Free = CBAVC_Free_OMX;

	fp=fopen("butterfly.264","rb");
	fread(aInputBuf, 1, aInBufSize, fp);
	fclose(fp);

	fp=fopen("C:/d240x320.yuv","wb"); // �����ļ���û�رգ���ʱ����

	while(aInBufSize>0)
	{
		NalSize = aInBufSize;

		PVAVCAnnexBGetNALUnit(aInputBuf, &pNalBuffer, &NalSize);

		aInputBuf += NalSize+4;
		aInBufSize -= NalSize+4;

		if (AVCDEC_FAIL == PVAVCDecGetNALType(pNalBuffer, NalSize, &NalType, &NalRefId))
			return false;

		if (AVC_NALTYPE_SPS == (AVCNalUnitType)NalType)
		{
			Status = PVAVCDecSeqParamSet(&(AvcHandle), pNalBuffer, NalSize);

			if (Status != AVCDEC_SUCCESS)
				return false;
		}
		else if (AVC_NALTYPE_PPS == (AVCNalUnitType) NalType)
		{
			Status = PVAVCDecPicParamSet(&(AvcHandle), pNalBuffer, NalSize);

			if (Status != AVCDEC_SUCCESS)
				return false;
		}
		else if (AVC_NALTYPE_SLICE == (AVCNalUnitType) NalType || AVC_NALTYPE_IDR == (AVCNalUnitType) NalType)
		{
			Status = PVAVCDecodeSlice(&(AvcHandle), pNalBuffer, NalSize);

			if (Status == AVCDEC_PICTURE_OUTPUT_READY)
			{
				AVCFrameIO Output;
				int Index, Release;

				Output.YCbCr[0] = Output.YCbCr[1] = Output.YCbCr[2] = NULL;
				Status = PVAVCDecGetOutput(&(AvcHandle), &Index, &Release, &Output);

				Index=0; // for debug

				fwrite(Output.YCbCr[0], 1, 320*240, fp);
				fwrite(Output.YCbCr[1], 1, 320*240/4, fp);
				fwrite(Output.YCbCr[2], 1, 320*240/4, fp);
				fflush(fp);

//				FlushOutput_OMX(aOutBufferForRendering);
			}
		}
		else if ((AVCNalUnitType)NalType == AVC_NALTYPE_SEI)
		{
			if (PVAVCDecSEI(&(AvcHandle), pNalBuffer, NalSize) != AVCDEC_SUCCESS)
			{
				return false;
			}
		}
		else if ((AVCNalUnitType)NalType == AVC_NALTYPE_AUD)
		{
			//PicType = pNalBuffer[1] >> 5;
		}
		else if ((AVCNalUnitType)NalType == AVC_NALTYPE_EOSTREAM || // end of stream
			(AVCNalUnitType)NalType == AVC_NALTYPE_EOSEQ || // end of sequence
			(AVCNalUnitType)NalType == AVC_NALTYPE_FILL) // filler data
		{
			return true;
		}
	}

	return 1;
}