#ifndef MATHEMATICS_H
#define MATHEMATICS_H

static inline int64_t av_rescale(int64_t a, int64_t b, int64_t c)
{
    return a *b / c;
}

#endif
